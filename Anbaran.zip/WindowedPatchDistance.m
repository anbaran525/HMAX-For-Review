function D = WindowedPatchDistance(Im,Patch)
if size(Patch,1)==4
    fgh=42;
    elseif size(Patch,1)==8
    dfv=34;
    elseif size(Patch,1)==12
    dfv=34;
elseif size(Patch,1)==16
    dfv=34;
end

dIm = size(Im,3);
dPatch = size(Im,3);
if(dIm ~= dPatch)
  fprintf('The patch and image must be of the same number of layers');
end
s = size(Patch);
s(3) = dIm;
Psqr = sum(sum(sum(Patch.^2)));
Imsq = Im.^2;
Imsq = sum(Imsq,3);
sum_support = [ceil(s(2)/2)-1,ceil(s(1)/2)-1,floor(s(2)/2),floor(s(1)/2)];
Imsq = sumfilter(Imsq,sum_support);
PI = zeros(size(Im(:,:,1)));

for i = 1:dIm
	PI = PI + conv2(Im(:,:,i),Patch(:,:,i), 'same');
end
D = Imsq - 2 * PI + Psqr + 10^-10;

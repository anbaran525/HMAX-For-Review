clear; clc;

% ***************    settings  **************  
svm_c = 0;  % SVM classifier
boost = 1;   % GentleBoost classifier

patch_num = [2 4 8 16 32 64 128 250];
%               1               2                       3                               4                    5                                   6                       7               8                       9                   10                      11                  12             13                   14                      15
tit = {'airplanes 101',	'cars (rear)',	'cars UIUC multiscale',	'cars UIUC',	'cars CBCL multiview',	 'cars side101', 	'faces101',	'face easy 101',	'leaves 101',	'leopards 101',	'motorbikes 101', 'ketch 101','hawksbill 101' ,  'chandelier 101' , 'watch 101'};
t_tit = tit(7);
% *****************************************


for r = 1: 10
    r
% ********  ORG   ********    
  file_name= ['org_',num2str(r),'.mat'];
  load (file_name)   % load org file
for i= 1:8
    N= patch_num(i);
XTrain = [C2res{1} C2res{2}]; %training examples as columns 
XTrainCopy = [XTrain(1:N,:) ; XTrain(251:250+N,:) ; XTrain(501:500+N,:) ; XTrain(751:750+N,:)];
XTest =  [C2res{3},C2res{4}]; %the labels of the training set
XTestCopy = [XTest(1:N,:) ; XTest(251:250+N,:) ; XTest(501:500+N,:) ; XTest(751:750+N,:)];
ytrain = [ones(size(C2res{1},2),1);-ones(size(C2res{2},2),1)]';%testing examples as columns
ytest = [ones(size(C2res{3},2),1);-ones(size(C2res{4},2),1)]; %the true labels of the test set
if  svm_c 
  Model2 = svmtrain(XTrainCopy',ytrain,'kernel_function','linear'); %training
  ry =  svmclassify (Model2,XTestCopy'); %predicting new labels
elseif boost
  ada = fitensemble(XTrainCopy',ytrain','GentleBoost',100,'tree');
  [ry score] = predict(ada,XTestCopy');
end  
successrate_org(r,i) = mean(ytest==ry)*100; 
end

% ******** NORM1 ********
  file_name= ['norm1_',num2str(r),'.mat'];
  load (file_name)   % load norm1 file
for i= 1:8
    N= patch_num(i);
XTrain = [C2res{1} C2res{2}]; %training examples as columns 
XTrainCopy = [XTrain(1:N,:) ; XTrain(251:250+N,:) ; XTrain(501:500+N,:) ; XTrain(751:750+N,:)];
XTest =  [C2res{3},C2res{4}]; %the labels of the training set
XTestCopy = [XTest(1:N,:) ; XTest(251:250+N,:) ; XTest(501:500+N,:) ; XTest(751:750+N,:)];
ytrain = [ones(size(C2res{1},2),1);-ones(size(C2res{2},2),1)]';%testing examples as columns
ytest = [ones(size(C2res{3},2),1);-ones(size(C2res{4},2),1)]; %the true labels of the test set
if  svm_c 
  Model2 = svmtrain(XTrainCopy',ytrain,'kernel_function','linear'); %training
  ry =  svmclassify (Model2,XTestCopy'); %predicting new labels
elseif boost
  ada = fitensemble(XTrainCopy',ytrain','GentleBoost',100,'tree');
  [ry score] = predict(ada,XTestCopy');
end  
successrate_norm1(r,i) = mean(ytest==ry)*100;
end
end
save PN_res.mat successrate_org successrate_norm1
successrate_org
successrate_norm1
m_org = mean(successrate_org)
std_org = std(successrate_org)
m_norm1 = mean(successrate_norm1)
std_norm1 = std(successrate_norm1)
x =1:8;
h1=errorbar(x,m_org,std_org,'-r'); hold on;
h2=errorbar(x,m_norm1,std_norm1,'-.b'); 
h1.LineWidth=1.2;
h2.LineWidth=1.2;
Bar2Axes = gca();ylabel('performance')
set(Bar2Axes, 'XTickLabel', [0 patch_num*4, 2000]);
title(t_tit);legend('ORG','ABS');grid on;

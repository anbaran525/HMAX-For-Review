N_tr=50;  % num of train picture
N_te=50;  % num of test picture
train_set.pos   = 'Image_Datasets/airTr/';
train_set.neg   = 'Image_Datasets/bckgTr/';
test_set.pos    = 'Image_Datasets/airTe/';
test_set.neg    = 'Image_Datasets/bckgTe/';

%%%%   clear the train and test folders  %%%%
k=dir (train_set.pos);k=k(3:end);
if size(k,1)>0
    for i=1:size(k,1)
        file_name = [train_set.pos,k(i).name];
        movefile(file_name,'obj');
    end
end

k = dir (train_set.neg);k=k(3:end);
if size(k,1)>0
    for i=1:size(k,1)
        file_name = [train_set.neg,k(i).name];
        movefile(file_name,'BG');
    end
end

k = dir (test_set.pos);k=k(3:end);
if size(k,1)>0
    for i=1:size(k,1)
        file_name = [test_set.pos,k(i).name];
        movefile(file_name,'obj');
    end
end

k = dir (test_set.neg);k=k(3:end);
if size(k,1)>0
    for i=1:size(k,1)
        file_name = [test_set.neg,k(i).name];
        movefile(file_name,'BG');
    end
end

%%%%   select random train and test pictures and copy in those folder  %%%%

    % airTr

for i = 1:N_tr
    k = dir ('obj/*.*');k=k(3:end);
    ii = floor(rand* size(k,1)) + 1;
    file_name = ['obj/',k(ii).name];
    movefile(file_name,train_set.pos)
end

    % airTe

for i = 1:N_te
    k = dir ('obj/*.*');k=k(3:end);
    ii = floor(rand* size(k,1)) + 1;
    file_name = ['obj/',k(ii).name];
    movefile(file_name,test_set.pos)
end

    % bckgTr

for i = 1:N_tr
    k = dir ('BG/*.*');k=k(3:end);
    ii = floor(rand* size(k,1)) + 1;
    file_name = ['BG/',k(ii).name];
    movefile(file_name,train_set.neg)
end

    % bckgTe

for i = 1:N_te
    k = dir ('BG/*.*');k=k(3:end);
    ii = floor(rand* size(k,1)) + 1;
    file_name = ['BG/',k(ii).name];
    movefile(file_name,test_set.neg)
end


clear;clc;
for n=1:10
    n
      datasetc()
patchSizes = [4 8 12 16]; %other sizes might be better, maybe not
                          %all sizes are required
			  
numPatchSizes = length(patchSizes);

%specify directories for training and testing images
train_set.pos   = 'Image_Datasets/airTr';
train_set.neg   = 'Image_Datasets/bckgTr';
test_set.pos    = 'Image_Datasets/airTe';
test_set.neg    = 'Image_Datasets/bckgTe';

cI = readAllImages(train_set,test_set); %cI is a cell containing
                                        %all training and testing images

if isempty(cI{1}) | isempty(cI{2})
  error(['No training images were loaded -- did you remember to' ...
	' change the path names?']);
end
READPATCHESFROMFILE =0; %use patches that were already computed
                         %(e.g., from natural images)
file_nameP= ['Patches',num2str(n),'.mat'];
%below the c1 prototypes are extracted from the images/ read from file
if ~READPATCHESFROMFILE
  numPatchesPerSize = 5; %more will give better results, but will
                           %take more time to compute
  cPatches = extractRandC1Patches(cI{1}, numPatchSizes, ...
      numPatchesPerSize, patchSizes); %fix: extracting from positive only 
%   save(file_nameP,'cPatches');                                    
else
  fprintf('reading patches');
  cPatches = load(file_nameP,'cPatches');                                    
  cPatches = cPatches.cPatches;
end

%----Settings for Testing --------%
rot = [90 -45 0 45];
c1ScaleSS = [1:2:18];
RF_siz    = [7:2:39];
c1SpaceSS = [8:2:22];
minFS     = 7;
maxFS     = 39;
div = [4:-.05:3.2];
Div       = div;
%--- END Settings for Testing --------%

fprintf(1,'Initializing gabor filters -- full set...');
%creates the gabor filters use to extract the S1 layer
[fSiz,filters,c1OL,numSimpleFilters] = init_gabor(rot, RF_siz, Div);
fprintf(1,'done\n');

%The actual C2 features are computed below for each one of the training/testing directories
fprintf('\n HMAX ORG START \n')
for i = 1:4
  C2res{i} = extractC2forcell(filters,fSiz,c1SpaceSS,c1ScaleSS,c1OL,cPatches,cI{i},numPatchSizes);
end
  file_name= ['org_',num2str(n),'.mat'];
  save (file_name)

  fprintf('HMAX norm1 START\n')  
for i = 1:4
   fprintf('%d /4 \n' ,i); 
  C2res{i} = extractC2forcell3(filters,fSiz,c1SpaceSS,c1ScaleSS,c1OL,cPatches,cI{i},numPatchSizes);
end
  file_name= ['norm1_',num2str(n),'.mat'];
  save (file_name)
end

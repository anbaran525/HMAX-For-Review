copy object images on "obj" folder
copy background images on "BG" folder
run demoRelease_for.m
open demoRelease_for_2.m and select classifier (svm , boost)
run demoRelease_for_2.m 

open demoRelease_for_PN.m and complete settings //this file is for patch number alter
run demoRelease_for_PN.m


FUNCTIONS
=================
WindowedPatchDistance.m - scans an image looking for the best match for a prototype with NORM2 distance
WindowedPatchDistance3.m - scans an image looking for the best match for a prototype with NORM1 distance


clear;
% ***************    classifier selection  **************  
svm_c = 1;  % SVM classifier
boost = 0;   % GentleBoost classifier

for r =1 : 10
    r
  file_name= ['org_',num2str(r),'.mat'];
  load (file_name)   %  ORG_?.MAT file

XTrain = [C2res{1} C2res{2}]; %training examples as columns 
XTest =  [C2res{3},C2res{4}]; %the labels of the training set
ytrain = [ones(size(C2res{1},2),1);-ones(size(C2res{2},2),1)]';%testing examples as columns
ytest = [ones(size(C2res{3},2),1);-ones(size(C2res{4},2),1)]; %the true labels of the test set
if  svm_c 
  Model2 = svmtrain(XTrain',ytrain,'kernel_function','linear'); %training
  ry =  svmclassify (Model2,XTest'); %predicting new labels
elseif boost
  ada = fitensemble(XTrain',ytrain','GentleBoost',100,'tree');
  [ry score] = predict(ada,XTest');
end  
successrate_org(r) = mean(ytest==ry)*100; 
% ******************************************
 file_name= ['norm1_',num2str(r),'.mat'];
  load (file_name)   %  load %  NORM1_?.MAT file

XTrain = [C2res{1} C2res{2}]; %training examples as columns 
XTest =  [C2res{3},C2res{4}]; %the labels of the training set
ytrain = [ones(size(C2res{1},2),1);-ones(size(C2res{2},2),1)]';%testing examples as columns
ytest = [ones(size(C2res{3},2),1);-ones(size(C2res{4},2),1)]; %the true labels of the test set
if  svm_c 
  Model2 = svmtrain(XTrain',ytrain,'kernel_function','linear'); %training
  ry =  svmclassify (Model2,XTest'); %predicting new labels
elseif boost
  ada = fitensemble(XTrain',ytrain','GentleBoost',100,'tree');
  [ry score] = predict(ada,XTest');
end  
successrate_norm1(r) = mean(ytest==ry)*100; 
end

x1=successrate_org
y1=successrate_norm1

mean(successrate_org)
std (successrate_org)

mean(successrate_norm1)
std (successrate_norm1)

[h,p,ci,stats] = ttest(x1-y1);
p
